"Image Downloader downloads images in a webpage by multi-threading."

__version__ = "0.0.1"
