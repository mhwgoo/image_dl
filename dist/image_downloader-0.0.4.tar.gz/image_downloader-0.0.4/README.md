"image_dl" is an image downloader to download multiple images in a webpage all at once by python multi-threading.
